
Example scripts for NoiseTools. Currently they cover only part of the functionality.
Some functions in NoiseTools include test code that may be useful as examples.
