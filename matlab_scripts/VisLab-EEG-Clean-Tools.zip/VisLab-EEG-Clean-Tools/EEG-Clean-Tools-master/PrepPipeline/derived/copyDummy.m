function EEG = copyDummy(EEG, varargin)
% This function does nothing.
     EEG = EEG; %#ok<ASGSL>

