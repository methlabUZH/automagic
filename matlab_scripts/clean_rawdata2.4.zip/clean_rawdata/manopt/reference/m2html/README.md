# m2html documentation module for Matlab code

Copy of the m2html project for Matlab code documentation (to be used as submodule).

Project page of m2html: https://www.artefact.tk/software/matlab/m2html/ 

Author of m2html: Guillaume Flandin

License of m2html: GNU GPL (see project website for details)

(I have made no contributions to this project: this is only a copy of it.)
