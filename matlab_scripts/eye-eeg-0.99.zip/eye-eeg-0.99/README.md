# EYE-EEG0.99
Version 0.99 of the EYE-EEG extension for EEGLAB

For more information on this software, visit https://www.eyetracking-eeg.org
