This folder contains programs to interface some of the BIOSIG 
data import functions to the EEGLAB toolbox (when present) by 
adding 3 menus in the "File > Import data" EEGLAB GUI.

For EEGLAB to detect the BIOSIG toolbox
(1) the current folder must be in the Matlab path or
(2) the BIOSIG folder must be placed in the "plugins" subfolder
    of the EEGLAB distribution.

For more information about the EEGLAB interface to BIOSIG 
contact eeglab@sccn.ucsd.edu.

Arnaud Delorme - Sept 11, 2004, San Diego, CA