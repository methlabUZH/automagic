Example scripts to illustrate nt_sca().


To run these scripts you'll need to download NoiseTools, and the example data 
files, and set the correct paths.  Some scripts also require FieldTrip. 

Each script is accompanied by an image file that shows the result to expect.  



example1: TBD.

