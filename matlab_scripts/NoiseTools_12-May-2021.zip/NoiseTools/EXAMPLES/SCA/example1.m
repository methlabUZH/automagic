disp('test example for nt_sca()');
disp('TBD');

set(gcf, 'PaperPositionMode', 'auto');
print ('-dtiff', 'example1.tif');
